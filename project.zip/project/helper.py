from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

from dataclasses import dataclass

from math import sqrt
SQRT_TWO = sqrt(2)

# the coordinates for the screen
MIN_X = -1000.0   # left most position of the screen will have x-coordinate = -1000
MAX_X = 1000.0    # right most x-coordinate of the screen
MIN_Y = -1000.0    # bottom y-coordinate of the screen
MAX_Y = 1000.0     # top y-coordinate of the screen
MIN_Z = -1.0      # near z-coordinate, we can safely ignore this 
MAX_Z = 1.0       # away z-coordinate, we can safely ignore this


POINT_SIZE = 6

# this function initializes opengl
def init_opengl (display_mode, window_width, window_height, window_x, window_y, window_title):
    glutInit()
    glutInitDisplayMode(display_mode)
    glutInitWindowSize(window_width, window_height)
    glutInitWindowPosition(window_x, window_y)
    glutCreateWindow(window_title)
    
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

    glClearColor(1.0, 1.0, 1.0, 1.0)

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(MIN_X, MAX_X, MIN_Y, MAX_Y, MIN_Z, MAX_Z)

# class for storing each Point
@dataclass
class Point:
    x: int # x and y co-ordinates of the point
    y: int

    color: (float, float, float, float)

# class for the buffers
@dataclass
class Buffer:
    min_x: int # min_x and min_y specify the position of our buffer on the screen
    min_y: int
    points: list[Point]

    def clear(self):
        self.points = []

    # draws all the points in the buffer
    def draw(self):
        glBegin(GL_POINTS)
        
        # print(f'drawing {len(self.points)} points')

        for point in self.points:
            r, g, b, a = point.color
            glColor4f(r, g, b, a)
            glVertex2i(self.min_x + point.x, self.min_y + point.y)

        glEnd()
        glDisable(GL_BLEND)

    def push_point (self, x: int, y: int, color: (float, float, float, float) = None) -> None:
        # print(f'push_point({x}, {y}) being called')
        if not color:
            color = glGetFloatv(GL_CURRENT_COLOR)
        r, g, b, a = color
        self.points.append(Point(x, y, (r, g, b, a)))

    # helper function for 8-way symmetry
    def _to_zone_0(self, x: int, y: int, x_mul: int, y_mul: int, swapped: bool) -> (int, int):
        if swapped:
            x, y = y, x
        return (x * x_mul, y * y_mul)

    # add the line from (ax, ay) to (bx, by) to the buffer
    def push_line(self, ax: int, ay: int, bx: int, by: int,
                  color: (float,float,float,float) = None) -> None:
        assert (isinstance(self, Buffer))

        if not color:
            color = tuple(glGetFloatv(GL_CURRENT_COLOR))

        print('push_line being called')

        dx = bx - ax
        dy = by - ay

        x_mul = 1 if dx >= 0 else -1
        y_mul = 1 if dy >= 0 else -1
        swapped = abs(dx) < abs(dy)
        ax, ay = self._to_zone_0(ax, ay, x_mul, y_mul, swapped)
        bx, by = self._to_zone_0(bx, by, x_mul, y_mul, swapped)

        dx = bx - ax
        dy = by - ay

        assert (dx >= 0 and dy >= 0)

        d = 2 * dy - dx

        delta_E = 2 * dy
        delta_NE = 2 * (dy - dx)

        while ax < bx or ay < by:
            # get actual coordinates back from zone 0
            x, y = self._to_zone_0(ax, ay, x_mul, y_mul, swapped)

            self.push_point(x, y, color)

            if d <= 0:
                ax += 1
                d += delta_E
            else:
                ax += 1
                ay += 1
                d += delta_E

    # add the circle centered at (center_x, center_y) with given radius
    def push_circle(self, center_x: int, center_y: int, radius: int,
                    color: (float, float, float, float) = None) -> None:
        assert (radius > 0)

        if not color:
            color = tuple(glGetFloatv(GL_CURRENT_COLOR))

        d = 1 - radius
        x, y = radius, 0

        while x >= y:
            # 8-way symmetry
            # updated to (sort-of) 16-way symmetry to avoid an issue that crops up when using tranparancy
            # points close to x <= y are not dense enough
            for st in range(8):
                val_x, val_y = x, y
                if st & 1: val_x *= -1
                if st & 2: val_y *= -1
                if st & 4: val_x, val_y = val_y, val_x

                self.push_point(val_x + center_x, val_y + center_y, color)

                if x != y: # without this the diagonals are way too prominent
                    rotated_x = int((val_x - val_y) / SQRT_TWO)
                    rotated_y = int((val_x + val_y) / SQRT_TWO)

                    self.push_point(rotated_x + center_x, rotated_y + center_y, color)

            if d <= 0:
                d += 2 * y + 3
                y += 1
            else:
                d += 2 * (y - x) + 5
                x -= 1
                y += 1

    # add the circular disk centered at (center_x, center_y) with given radius
    # in other words,  this method pushes the filled-circle
    def push_disk(self, center_x: int, center_y: int, radius: int,
                  color: (float, float, float, float) = None) -> None:
        assert (radius > 0)

        if not color:
            color = tuple(glGetFloatv(GL_CURRENT_COLOR))

        for r in range(1, radius + 1, POINT_SIZE):
            self.push_circle(center_x, center_y, r, color)



from physics import *
from helper import *

from random import seed, uniform
seed()

class Attractor(Mass):
    def __init__(self, x: float, y: float):
        self.position = Vector2D(x, y)
        self.mass = uniform(10.0, 30.0)
        self.color = (0.0, 0.0, 0.0, 0.0)

    def push_to_buffer(self, buffer: Buffer) -> None:
        pass

class Body(Mass):
    def __init__(self, x: float, y: float):
        self.position = Vector2D(x, y)
        self.mass = uniform(0.1, 0.5)
        self.velocity = Vector2D(uniform(0.0, 5.0), uniform(0.0, 5.0))
        self.color = (uniform(0.0, 1.0), uniform(0.0, 1.0), uniform(0.0, 1.0), uniform(0.0, 0.01))
    def push_to_buffer(self, buffer: Buffer) -> None:
        buffer.push_disk(int(self.position.x), int(self.position.y), int(self.mass * 16.0), self.color)

@dataclass
class AttractorField:
    attractor: Attractor
    bodies: list[Body]
    buffer: Buffer

    def update (self) -> None:
        for body in self.bodies:
            body.apply_force(body.calculate_gravity(self.attractor))
            body.push_to_buffer(self.buffer)

    def draw (self) -> None:
        self.buffer.draw()
        self.buffer.clear()

    @classmethod
    def generate_field (cls, x: int, y: int, body_n: int):
        res = cls(Attractor(float(x), float(y)), [], Buffer(x, y, []))
        for i in range(body_n):
            res.bodies.append(Body(uniform(-150.0, 150.0), uniform(-150.0, 150.0)))
        return res

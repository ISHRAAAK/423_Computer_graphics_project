from dataclasses import dataclass

from math import sqrt

@dataclass
class Vector2D:
    x: float 
    y: float

    def __add__(self, other):
        return Vector2D(self.x + other.x, self.y + other.y)

    def __sub__(self, other):
        return Vector2D(self.x - other.x, self.y - other.y)

    def __mul__(self, r: float):
        return Vector2D(self.x * r, self.y * r)

    def __truediv__(self, r: float):
        return Vector2D(self.x / r, self.y / r)

    def norm2(self) -> float:
        return self.x * self.x + self.y * self.y

    def norm(self) -> float:
        return sqrt(self.norm2())

    def normalize(self):
        return self / self.norm()

@dataclass
class Mass:
    position: Vector2D
    velocity: Vector2D
    mass: float
    color: (float, float, float, float)

    # calculate gravitational force on this mass by the other mass
    def calculate_gravity (self, other_mass) -> Vector2D:
        G = 1.0
        rvec = other_mass.position - self.position
        dist2 = max(30, min(300, rvec.norm2()))
        return rvec.normalize() * ((self.mass * other_mass.mass * G) / dist2)

    # apply given force on the object
    def apply_force (self, force: Vector2D) -> None:
        self.velocity = self.velocity + (force / self.mass)
        self.position = self.position + self.velocity

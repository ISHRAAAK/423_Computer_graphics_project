from helper import *
from physics import *

from attractor_field import *

field1 = AttractorField.generate_field(0, 0, 10)

first_call = True
def display_func():
    global first_call
    if first_call:
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        first_call = False
    else:
        glClear(GL_DEPTH_BUFFER_BIT)

    glPointSize(POINT_SIZE)

    field1.update()
    field1.draw()

    glFlush()
    # glutSwapBuffers()

def idle_func():
    glutPostRedisplay()

def main():
    # changes GLUT_DOUBLE to GLUT_SINGLE
    init_opengl(GLUT_SINGLE | GLUT_RGBA, 1000, 1000, 100, 100, b'Project')

    glutDisplayFunc(display_func)
    glutIdleFunc(idle_func)

    glutMainLoop()

if __name__ == '__main__':
    main()
